package payment; 

  

import java.awt.EventQueue; 

  

import javax.swing.JFrame; 

import javax.swing.JLabel; 

import java.awt.Font; 

import javax.swing.JTextField; 

import javax.swing.JButton; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

  

public class CreateAccount { 

  

public JFrame frame; 

private JTextField textField; 

private JTextField textField_1; 

private JTextField textField_2; 

private JTextField textField_3; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

CreateAccount window = new CreateAccount(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public CreateAccount() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JLabel lblNewLabel = new JLabel("First Name"); 

lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel.setBounds(23, 24, 113, 28); 

frame.getContentPane().add(lblNewLabel); 

 

JLabel lblLastName = new JLabel("Last Name"); 

lblLastName.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblLastName.setBounds(23, 75, 113, 28); 

frame.getContentPane().add(lblLastName); 

 

JLabel lblEmail = new JLabel("Email"); 

lblEmail.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblEmail.setBounds(23, 124, 113, 28); 

frame.getContentPane().add(lblEmail); 

 

JLabel lblPassword = new JLabel("Password"); 

lblPassword.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblPassword.setBounds(23, 173, 113, 28); 

frame.getContentPane().add(lblPassword); 

 

textField = new JTextField(); 

textField.setBounds(146, 30, 179, 20); 

frame.getContentPane().add(textField); 

textField.setColumns(10); 

 

textField_1 = new JTextField(); 

textField_1.setBounds(146, 81, 179, 20); 

frame.getContentPane().add(textField_1); 

textField_1.setColumns(10); 

 

textField_2 = new JTextField(); 

textField_2.setBounds(146, 130, 179, 20); 

frame.getContentPane().add(textField_2); 

textField_2.setColumns(10); 

 

textField_3 = new JTextField(); 

textField_3.setBounds(146, 179, 179, 20); 

frame.getContentPane().add(textField_3); 

textField_3.setColumns(10); 

 

JButton btnNewButton = new JButton("Back"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Login log = new Login(); 

log.frame.setVisible(true); 

 

} 

}); 

btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton.setBounds(49, 227, 89, 23); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnNewButton_1 = new JButton("Ok"); 

btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(266, 228, 89, 23); 

frame.getContentPane().add(btnNewButton_1); 

} 

  

}
