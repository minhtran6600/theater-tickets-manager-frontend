package payment; 

  

import java.awt.EventQueue; 

import java.awt.Font; 

  

import javax.swing.JButton; 

import javax.swing.JFrame; 

import javax.swing.JLabel; 

import javax.swing.JTextField; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

  

public class EditPrices1 { 

  

public JFrame frame; 

private JTextField textField; 

private JTextField textField_2; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

EditPrices1 window = new EditPrices1(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 * @wbp.parser.entryPoint 

 */ 

public EditPrices1() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JLabel lblNewLabel = new JLabel("Date of Performance:"); 

lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 12)); 

lblNewLabel.setBounds(25, 42, 142, 14); 

frame.getContentPane().add(lblNewLabel); 

 

JButton btnNewButton = new JButton("Back"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

AdminHomepage ad = new AdminHomepage(); 

ad.frame.setVisible(true); 

} 

}); 

btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 12)); 

btnNewButton.setBounds(65, 213, 89, 23); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnNewButton_1 = new JButton("OK"); 

btnNewButton_1.addMouseListener(new MouseAdapter() { 

@Override 

//Click on button causes new window to open and this window to close 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

EditPrices2 ep2 = new EditPrices2(); 

ep2.frame.setVisible(true); 

 

}}); 

btnNewButton_1.setFont(new Font("Arial Black", Font.PLAIN, 12)); 

btnNewButton_1.setBounds(256, 213, 89, 23); 

frame.getContentPane().add(btnNewButton_1); 

 

textField = new JTextField(); 

textField.setBounds(200, 40, 150, 20); 

frame.getContentPane().add(textField); 

textField.setColumns(10); 

 

JLabel lblNewLabel_2 = new JLabel("Price Editor pg 1"); 

lblNewLabel_2.setBounds(10, 0, 89, 14); 

frame.getContentPane().add(lblNewLabel_2); 

 

JLabel lblNewLabel_3 = new JLabel("Time:"); 

lblNewLabel_3.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel_3.setBounds(121, 90, 46, 14); 

frame.getContentPane().add(lblNewLabel_3); 

 

textField_2 = new JTextField(); 

textField_2.setBounds(200, 89, 150, 20); 

frame.getContentPane().add(textField_2); 

textField_2.setColumns(10); 

} 

  

  

  

} 