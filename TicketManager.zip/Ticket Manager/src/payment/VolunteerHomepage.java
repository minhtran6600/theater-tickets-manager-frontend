package payment; 

  

import java.awt.EventQueue; 

  

import javax.swing.JFrame; 

import javax.swing.JButton; 

import java.awt.Font; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

  

  

public class VolunteerHomepage { 

  

public JFrame frame; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

VolunteerHomepage window = new VolunteerHomepage(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public VolunteerHomepage() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JButton btnNewButton = new JButton("Playhouse"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Playhouse window = new Playhouse(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton.setBounds(10, 11, 193, 35); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnNewButton_1 = new JButton("Civic Center"); 

btnNewButton_1.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

CivicCenter window = new CivicCenter(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(10, 87, 193, 35); 

frame.getContentPane().add(btnNewButton_1); 

 

JButton btnNewButton_2 = new JButton("Season Ticket Holders"); 

btnNewButton_2.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

SeasonInfo window = new SeasonInfo(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_2.setBounds(10, 161, 193, 35); 

frame.getContentPane().add(btnNewButton_2); 

 

JButton btnNewButton_3 = new JButton("Logout"); 

btnNewButton_3.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Login window = new Login(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton_3.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_3.setBounds(268, 164, 135, 30); 

frame.getContentPane().add(btnNewButton_3); 
JButton btnNewButton_4 = new JButton("Refund");
btnNewButton_4.setFont(new Font("Arial", Font.PLAIN, 14));
btnNewButton_4.setBounds(268, 22, 135, 35);
frame.getContentPane().add(btnNewButton_4);

} 
} 