package payment; 

  

import java.awt.EventQueue; 

  

import javax.swing.JFrame; 

import javax.swing.JScrollBar; 

import javax.swing.JTextField; 

import javax.swing.JButton; 

import java.awt.Font; 

import javax.swing.JLabel; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

  

public class SeasonInfo { 

  

public JFrame frame; 

private JTextField textField; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

SeasonInfo window = new SeasonInfo(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public SeasonInfo() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JScrollBar scrollBar = new JScrollBar(); 

scrollBar.setBounds(241, 40, 17, 153); 

frame.getContentPane().add(scrollBar); 

 

textField = new JTextField(); 

textField.setBounds(100, 40, 131, 153); 

frame.getContentPane().add(textField); 

textField.setColumns(10); 

 

JButton btnNewButton = new JButton("Ok"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

HolderInfo window = new HolderInfo(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton.setBounds(312, 50, 89, 23); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnNewButton_1 = new JButton("Back"); 

btnNewButton_1.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

VolunteerHomepage vh = new VolunteerHomepage(); 

vh.frame.setVisible(true); 

} 

}); 

btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(312, 135, 89, 23); 

frame.getContentPane().add(btnNewButton_1); 

 

JLabel lblNewLabel = new JLabel("Select Name"); 

lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel.setBounds(118, 11, 113, 23); 

frame.getContentPane().add(lblNewLabel); 

} 

} 

 

 

 

 

 

 