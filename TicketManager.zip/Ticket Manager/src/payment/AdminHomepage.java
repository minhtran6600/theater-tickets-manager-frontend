package payment; 

  

import java.awt.EventQueue; 

  

import javax.swing.JFrame; 

import java.awt.Font; 

import javax.swing.JButton; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

  

  

public class AdminHomepage { 

  

public JFrame frame; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

AdminHomepage window = new AdminHomepage(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public AdminHomepage() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JButton btnNewButton = new JButton("Playhouse"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

EditPrices1 window = new EditPrices1(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

btnNewButton.setBounds(44, 11, 146, 71); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnCivicCenter = new JButton("Civic Center"); 

btnCivicCenter.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

EditPrices1 window = new EditPrices1(); 

window.frame.setVisible(true); 

} 

}); 

btnCivicCenter.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

btnCivicCenter.setBounds(44, 117, 146, 71); 

frame.getContentPane().add(btnCivicCenter); 

 

JButton btnNewButton_1 = new JButton("Logout"); 

btnNewButton_1.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Login window = new Login(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton_1.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(253, 174, 89, 23); 

frame.getContentPane().add(btnNewButton_1); 

 

JButton btnNewButton_2 = new JButton("Go To Sell Portal"); 

btnNewButton_2.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

VolunteerHomepage vh = new VolunteerHomepage(); 

vh.frame.setVisible(true); 

} 

}); 

btnNewButton_2.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

btnNewButton_2.setBounds(213, 63, 178, 71); 

frame.getContentPane().add(btnNewButton_2); 

} 

} 