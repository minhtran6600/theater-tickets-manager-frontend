package payment; 

  

import java.awt.EventQueue; 

  

import javax.swing.JFrame; 

import javax.swing.JLabel; 

import java.awt.Font; 

import javax.swing.JTextField; 

import javax.swing.JButton; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

  

public class Checkout { 

  

public JFrame frame; 

private JTextField textField; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

Checkout window = new Checkout(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public Checkout() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JLabel lblNewLabel = new JLabel("Total Due:"); 

lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel.setBounds(24, 52, 86, 28); 

frame.getContentPane().add(lblNewLabel); 

 

textField = new JTextField(); 

textField.setBounds(148, 50, 217, 36); 

frame.getContentPane().add(textField); 

textField.setColumns(10); 

 

JButton btnNewButton_1 = new JButton("Card"); 

btnNewButton_1.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Card cd = new Card(); 

cd.frame.setVisible(true); 

} 

}); 

btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(166, 161, 100, 36); 

frame.getContentPane().add(btnNewButton_1); 

 

JButton btnNewButton_2 = new JButton("Check\r\n"); 

btnNewButton_2.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Check ck = new Check(); 

ck.frame.setVisible(true); 

} 

}); 

btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_2.setBounds(296, 161, 100, 36); 

frame.getContentPane().add(btnNewButton_2); 

 

JButton btnNewButton_1_1 = new JButton("Cash"); 

btnNewButton_1_1.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Cash ca = new Cash(); 

ca.frame.setVisible(true); 

} 

}); 

btnNewButton_1_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1_1.setBounds(42, 161, 100, 36); 

frame.getContentPane().add(btnNewButton_1_1); 

 

JButton btnNewButton = new JButton("Back"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

VolunteerHomepage vh = new VolunteerHomepage(); 

vh.frame.setVisible(true); 

} 

}); 

btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton.setBounds(166, 227, 100, 23); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnNewButton_3 = new JButton("Group Discount"); 

btnNewButton_3.setBounds(21, 11, 203, 23); 

frame.getContentPane().add(btnNewButton_3); 

} 

} 
