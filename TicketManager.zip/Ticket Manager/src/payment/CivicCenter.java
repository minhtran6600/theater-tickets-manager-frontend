package payment; 

  

import java.awt.EventQueue; 

import java.awt.Font; 

  

import javax.swing.JButton; 

import javax.swing.JFrame; 

import javax.swing.JLabel; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

  

public class CivicCenter { 

  

public JFrame frame; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

CivicCenter window = new CivicCenter(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public CivicCenter() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JButton btnNewButton = new JButton("Pay Now"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

Checkout window = new Checkout(); 

window.frame.setVisible(true); 

} 

}); 

btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton.setBounds(38, 227, 89, 23); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnNewButton_1 = new JButton("Exchange"); 

btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(262, 227, 109, 23); 

frame.getContentPane().add(btnNewButton_1); 

 

JLabel lblNewLabel = new JLabel("Seating selection goes here"); 

lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel.setBounds(97, 36, 229, 61); 

frame.getContentPane().add(lblNewLabel); 

} 

  

} 