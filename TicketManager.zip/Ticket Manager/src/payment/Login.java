package payment; 

  

import java.awt.EventQueue; 

  

import javax.swing.JFrame; 

import javax.swing.JLabel; 

import java.awt.Font; 

import javax.swing.JButton; 

import javax.swing.JTextField; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

import java.awt.event.ActionListener; 

import java.awt.event.ActionEvent; 

  

public class Login { 

  

public JFrame frame; 

private JTextField textField; 

private JTextField textField_1; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

Login window = new Login(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public Login() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JLabel lblNewLabel = new JLabel("Email:"); 

lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel.setBounds(43, 51, 95, 14); 

frame.getContentPane().add(lblNewLabel); 

 

JLabel lblNewLabel_1 = new JLabel("Password:"); 

lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel_1.setBounds(43, 108, 95, 14); 

frame.getContentPane().add(lblNewLabel_1); 

 

JButton btnNewButton = new JButton("Login"); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

VolunteerHomepage VH = new VolunteerHomepage(); 

VH.frame.setVisible(true); 

} 

}); 

btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton.setBounds(10, 165, 180, 54); 

frame.getContentPane().add(btnNewButton); 

 

textField = new JTextField(); 

textField.setBounds(148, 50, 187, 20); 

frame.getContentPane().add(textField); 

textField.setColumns(10); 

 

textField_1 = new JTextField(); 

textField_1.setBounds(148, 107, 187, 20); 

frame.getContentPane().add(textField_1); 

textField_1.setColumns(10); 

 

JButton btnNewButton_1 = new JButton("Create Account"); 

btnNewButton_1.addActionListener(new ActionListener() { 

public void actionPerformed(ActionEvent e) { 

} 

}); 

btnNewButton_1.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

CreateAccount acc = new CreateAccount(); 

acc.frame.setVisible(true); 

} 

}); 

btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(246, 165, 178, 54); 

frame.getContentPane().add(btnNewButton_1); 

 

JButton tempAdminLogin = new JButton(""); 

tempAdminLogin.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

AdminHomepage AH = new AdminHomepage(); 

AH.frame.setVisible(true); 

} 

}); 

tempAdminLogin.setBounds(20, 230, 12, 20); 

frame.getContentPane().add(tempAdminLogin); 

} 

} 

 