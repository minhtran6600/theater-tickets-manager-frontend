package payment; 

  

import java.awt.EventQueue; 

  

import javax.swing.JFrame; 

import javax.swing.JButton; 

import java.awt.event.MouseAdapter; 

import java.awt.event.MouseEvent; 

import java.awt.Font; 

import javax.swing.JLabel; 

import javax.swing.JTextField; 

  

public class HolderInfo { 

  

public JFrame frame; 

private JTextField textField; 

private JTextField textField_1; 

private JTextField textField_2; 

private JTextField textField_3; 

private JTextField textField_4; 

private JTextField textField_5; 

private JTextField textField_6; 

private JTextField textField_7; 

  

/** 

 * Launch the application. 

 */ 

public static void main(String[] args) { 

EventQueue.invokeLater(new Runnable() { 

public void run() { 

try { 

HolderInfo window = new HolderInfo(); 

window.frame.setVisible(true); 

} catch (Exception e) { 

e.printStackTrace(); 

} 

} 

}); 

} 

  

/** 

 * Create the application. 

 */ 

public HolderInfo() { 

initialize(); 

} 

  

/** 

 * Initialize the contents of the frame. 

 */ 

private void initialize() { 

frame = new JFrame(); 

frame.setBounds(100, 100, 450, 300); 

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

frame.getContentPane().setLayout(null); 

 

JButton btnNewButton = new JButton("Ok"); 

btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

VolunteerHomepage vh = new VolunteerHomepage(); 

vh.frame.setVisible(true); 

} 

}); 

btnNewButton.setBounds(335, 180, 89, 23); 

frame.getContentPane().add(btnNewButton); 

 

JButton btnNewButton_1 = new JButton("Back"); 

btnNewButton_1.addMouseListener(new MouseAdapter() { 

@Override 

public void mouseClicked(MouseEvent e) { 

frame.dispose(); 

VolunteerHomepage vh = new VolunteerHomepage(); 

vh.frame.setVisible(true); 

} 

}); 

btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14)); 

btnNewButton_1.setBounds(335, 221, 89, 23); 

frame.getContentPane().add(btnNewButton_1); 

 

JLabel lblNewLabel = new JLabel("Name:"); 

lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblNewLabel.setBounds(10, 11, 119, 30); 

frame.getContentPane().add(lblNewLabel); 

 

JLabel lblAddress = new JLabel("Address:"); 

lblAddress.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblAddress.setBounds(10, 52, 119, 30); 

frame.getContentPane().add(lblAddress); 

 

JLabel lblPhone = new JLabel("Phone:"); 

lblPhone.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblPhone.setBounds(10, 93, 119, 30); 

frame.getContentPane().add(lblPhone); 

 

JLabel lblSeat = new JLabel("Seat:"); 

lblSeat.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblSeat.setBounds(10, 134, 119, 30); 

frame.getContentPane().add(lblSeat); 

 

JLabel lblVenu = new JLabel("Venue:"); 

lblVenu.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblVenu.setBounds(10, 175, 119, 30); 

frame.getContentPane().add(lblVenu); 

 

JLabel lblEmail = new JLabel("Email:"); 

lblEmail.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblEmail.setBounds(10, 216, 119, 30); 

frame.getContentPane().add(lblEmail); 

 

textField = new JTextField(); 

textField.setBounds(66, 18, 97, 20); 

frame.getContentPane().add(textField); 

textField.setColumns(10); 

 

textField_1 = new JTextField(); 

textField_1.setBounds(89, 59, 214, 20); 

frame.getContentPane().add(textField_1); 

textField_1.setColumns(10); 

 

textField_2 = new JTextField(); 

textField_2.setBounds(173, 18, 130, 20); 

frame.getContentPane().add(textField_2); 

textField_2.setColumns(10); 

 

textField_3 = new JTextField(); 

textField_3.setBounds(77, 100, 192, 20); 

frame.getContentPane().add(textField_3); 

textField_3.setColumns(10); 

 

textField_4 = new JTextField(); 

textField_4.setBounds(77, 141, 192, 20); 

frame.getContentPane().add(textField_4); 

textField_4.setColumns(10); 

 

textField_5 = new JTextField(); 

textField_5.setBounds(77, 182, 192, 20); 

frame.getContentPane().add(textField_5); 

textField_5.setColumns(10); 

 

textField_6 = new JTextField(); 

textField_6.setBounds(77, 223, 192, 20); 

frame.getContentPane().add(textField_6); 

textField_6.setColumns(10); 

 

JLabel lblSeasonId = new JLabel("Season ID"); 

lblSeasonId.setFont(new Font("Arial Black", Font.PLAIN, 14)); 

lblSeasonId.setBounds(341, 36, 83, 30); 

frame.getContentPane().add(lblSeasonId); 

 

textField_7 = new JTextField(); 

textField_7.setBounds(335, 77, 89, 20); 

frame.getContentPane().add(textField_7); 

textField_7.setColumns(10); 

} 

} 
