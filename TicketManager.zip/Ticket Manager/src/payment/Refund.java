package payment;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Refund {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Refund window = new Refund();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Refund() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Seat");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblNewLabel.setBounds(53, 10, 52, 44);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblVenue = new JLabel("Venue");
		lblVenue.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblVenue.setBounds(53, 72, 62, 44);
		frame.getContentPane().add(lblVenue);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblDate.setBounds(53, 137, 52, 44);
		frame.getContentPane().add(lblDate);
		
		JLabel lblTime = new JLabel("Time");
		lblTime.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblTime.setBounds(53, 191, 62, 49);
		frame.getContentPane().add(lblTime);
		
		textField = new JTextField();
		textField.setBounds(194, 25, 153, 25);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(194, 87, 153, 25);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(194, 149, 153, 25);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(194, 208, 153, 25);
		frame.getContentPane().add(textField_3);
		
		JButton btnNewButton = new JButton("Ok");
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(345, 63, 83, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				VolunteerHomepage window = new VolunteerHomepage();
				window.frame.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_1.setBounds(345, 184, 83, 21);
		frame.getContentPane().add(btnNewButton_1);
	}
}
